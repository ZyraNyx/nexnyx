"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function VaultEnterPage() {
    const router = useRouter();

    useEffect(() => {
        const timer = setTimeout(() => {
            router.push("/vault");
        }, 5000); // 5 seconden wachten

        return () => clearTimeout(timer);
    }, [router]);

    return (
        <div className="min-h-screen bg-black flex items-center justify-center">
            <video
                className="w-full max-w-2xl rounded-xl shadow-xl"
                autoPlay
                muted
                playsInline
            >
                <source src="/videos/vault-opening.mp4" type="video/mp4" />
                Your browser does not support the video tag.
            </video>
        </div>
    );
}
