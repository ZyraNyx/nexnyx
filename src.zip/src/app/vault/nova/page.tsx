import withAuth from "@/components/withAuth";
import NovaPage from "./NovaPage";

export default withAuth(NovaPage);
