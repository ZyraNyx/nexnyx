"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function DemoIntroPage() {
    const router = useRouter();

    // ⏳ Automatische redirect na 4.5 seconden
    useEffect(() => {
        const timeout = setTimeout(() => {
            router.push("/demo/start");
        }, 4500);
        return () => clearTimeout(timeout);
    }, [router]);

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white relative overflow-hidden">
            {/* 🎥 Video background */}
            <video
                autoPlay
                muted
                playsInline
                className="absolute top-0 left-0 w-full h-full object-cover opacity-30"
            >
                <source src="/videos/naela-smile.mp4" type="video/mp4" />
            </video>

            {/* 🔮 Overlay content */}
            <div className="z-10 text-center px-6 space-y-4">
                <h1 className="text-4xl md:text-5xl font-bold">You’ve been chosen.</h1>
                <p className="text-lg md:text-xl text-purple-300">The Vault has scanned your frequency.</p>
                <p className="text-sm text-zinc-400">Opening ritual is in progress...</p>
            </div>
        </div>
    );
}
