// 📁 src/app/demo/layout.tsx

import React from "react";
import Image from "next/image";

export default function DemoLayout({ children }: { children: React.ReactNode }) {
    return (
        <div className="min-h-screen bg-black text-white flex items-center justify-center px-4 py-10">
            <div className="bg-zinc-900 rounded-2xl shadow-2xl p-6 w-full max-w-4xl flex flex-col md:flex-row items-center md:items-start gap-8">
                {/* ✅ Naela avatar */}
                <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-purple-600 shadow-md">
                    <Image
                        src="/images/naela-avatar.jpg"
                        alt="Naela Nyx"
                        width={128}
                        height={128}
                        className="object-cover w-full h-full"
                    />
                </div>

                {/* ✅ Demo flow content */}
                <div className="flex-1 w-full">{children}</div>
            </div>
        </div>
    );
}
